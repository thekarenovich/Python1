from some_module import y, fun
print("3.py : y = ", y)
y = 42
fun(y)
print( "3.py : y = ", y)

# from some_module import GLOBAL_VAR
# GLOBAL_VAR = 42

# А при этом коде изменится лишь перменная в главном файле, не в самом модуле
# доказательство:

# 3.py:
# from some_module import GLOBAL_VAR, f
# GLOBAL_VAR = 42
# print( f() )
# вывод - True

# some_module.py:
# def f():
#	return GLOBAL_VAR
# GLOBAL_VAR = True
