def fun(x):
	global y
	y = x
	return(y)

y = True
print('some_module.py : y = ', y)
