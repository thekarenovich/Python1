class Erik:
    def __init__(self, x=0, y=1, z=2):
        self.__x = x
        self.__y = y
        self.z = z

object1 = Erik()
