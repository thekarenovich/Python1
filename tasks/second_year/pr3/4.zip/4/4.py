from some_module import *

print('z = ', object1.z)

try:
	print('y = ', object1.y)
except:
	print("y exists BUT atribute y is private")

try:
	print('x = ', object1.x)
except:
	print("x exists BUT atribute x is private")